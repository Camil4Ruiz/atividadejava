/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner; // Importa a classe Scanner, que é usada para ler entradas do usuário.

public class Main {

    public static void main(String[] args) {
        // Cria um objeto Scanner para ler dados da entrada padrão.
        Scanner leitor = new Scanner(System.in);

        // Solicita que o usuário digite seu nome e lê a entrada do usuário
        System.out.println("Digite seu nome:");
        String nome = leitor.nextLine(); // Armazena o nome digitado pelo usuário na variável 'nome'

       
        System.out.println("Digite sua idade:");
        int idade = Integer.parseInt(leitor.nextLine()); // "Integer" converte a entrada do usuário para um número inteiro e armazena em 'idade'

      
        System.out.println("Digite o valor de sua compra:");
        double compra = Double.parseDouble(leitor.nextLine()); // Converte a entrada do usuário para um número de ponto flutuante e armazena em 'compra'

        // Determina a porcentagem de cashback com base na idade e no valor da compra.
        double porcentagem; // "Double" declara uma variável para armazenar a porcentagem do cashback.
        
        if (idade >= 21) { // Verifica se a idade do usuário é 21 anos ou mais ">="
            // Se a idade for 21 ou mais, determina a porcentagem de cashback com base no valor da compra.
            porcentagem = (compra < 1000) ? 5.0 : 7.0; // Se a compra for menor que 1000, a porcentagem é 5%; caso contrário, é 7%.
        } else {
            // Se a idade for menor que 21, determina a porcentagem de cashback com base no valor da compra.
            porcentagem = (compra < 1000) ? 7.0 : 10.0; // Se a compra for menor que 1000, a porcentagem é 7%; caso contrário, é 10%
        }

        // Usa System.out.printf para formatar a saída: o nome, a idade e a porcentagem de cashback.
        System.out.printf("\nCliente: %s\nIdade: %d\nPorcentagem de Cashback: %.0f%%%n", nome, idade, porcentagem);
        // "%.0f%" formata a porcentagem como um número inteiro sem casas decimais e adiciona o símbolo de porcentagem (%)
         // Exibe a porcentagem de cashback aplicada.

        // Fecha o objeto Scanner para liberar os recursos utilizados
        leitor.close();
    }
}
